library(tidyverse)
library(naniar)
library(RColorBrewer)
theme_set(theme_bw(16))

ds_salfix <- read_csv("DSsalary.csv")


ds_salfix <- ds_salfix %>% 
    rename(Avg.Salary.K = 'Avg Salary(K)',
           Job.Title = 'Job Title') %>% # Suggestion: Trim names of job titles (1st 10 characters or manually)
    mutate(Avg.Salary.K = as.numeric(Avg.Salary.K)) %>% 
    replace_with_na_all(condition = ~.x == -1)

industry <- pull(ds_salfix, Industry) %>%
    unique() %>%
    na.omit()
    
industry <- sort(industry)

# Boxplot
box <- function(df){    
    ggplot(data = df %>% filter(selected)) +
        geom_boxplot(aes(x = Avg.Salary.K, 
                         y = fct_reorder(Industry, Avg.Salary.K, median),
                         fill = Industry)) + #suggestion: reorder box plots
        theme(legend.position="none",
              axis.text.y = element_text(size = 14),
              axis.text.x = element_text(size = 14),
              axis.title = element_text(size = 16),
              plot.title = element_text(size = 18)) +
        scale_fill_brewer(palette = "Spectral")+
        labs(title= "Average Salaries vs Industry", 
             x= "Average Salary in Thousands",
             y= "Industry")
}
ui <- fluidPage(
    titlePanel(h1("Average Salaries for Data Science Jobs", align = "center")),
    sidebarLayout(
        sidebarPanel(checkboxGroupInput("industry", "Industry", industry, industry[1:12])),
        mainPanel(plotOutput("boxplot"))
    )
)

server <- function(input, output){
    df_subset <- reactive({
        ds_salfix %>% mutate(
            selected = (
                (Industry %in% input$industry)
            ))
    })
    output$boxplot = renderPlot(box(df_subset()), height= 1200, width = 800)
}

shinyApp(ui, server)